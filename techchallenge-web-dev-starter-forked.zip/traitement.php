<?php
echo "Traitement";
?>